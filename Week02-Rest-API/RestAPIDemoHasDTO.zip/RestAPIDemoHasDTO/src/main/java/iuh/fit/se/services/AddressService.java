package iuh.fit.se.services;

import iuh.fit.se.entities.Address;

public interface AddressService {
    public Address save(Address address);
}
